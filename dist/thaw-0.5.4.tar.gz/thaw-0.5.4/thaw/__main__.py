import thaw

def run():
    thaw.main()
    
if __name__ == "__main__":
    run()