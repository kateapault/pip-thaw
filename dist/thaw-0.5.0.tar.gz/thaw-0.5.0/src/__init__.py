import platform

if platform.python_version()[0] == '2':
    print("It looks like you're using Python 2. Please use Python 3 instead.")