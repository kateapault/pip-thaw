from thaw import thaw

thaw.main()